package cn.itedus.lottery.test.model;

public class User {
}
